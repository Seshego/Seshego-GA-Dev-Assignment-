/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assassment;

import java.util.Random;

/**
 *
 * 
 */
public class Assassment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("--------------Before-------------");
        
        int [] numbers = new int [8];
        //Random ranObject = rand.nextInt()
        
        Random rand  = new Random();
        
        for(int x = 0; x < numbers.length; x++){
            
            
            numbers[x] = rand.nextInt(100);
            
            
        }
        for(int x = 0; x < numbers.length; x++){
            
            System.out.println(" " + numbers[x]);
            
        }
        int [] sortedNumbs = numbers;
        int temp;
        
        System.out.println("------------After----------------------");
        
        for(int a = 1; a < sortedNumbs.length; a++){
            
            for(int b = a; b > 0; b--)
            {
                if (sortedNumbs[b] < sortedNumbs[b - 1]){
                    temp = sortedNumbs[b];
                    sortedNumbs[b] = sortedNumbs[b - 1];
                    sortedNumbs[b - 1] = temp;
                     
                }
                       
            }
             
        }
        
        for(int i = 0; i < sortedNumbs.length; i++){
            
            System.out.println(sortedNumbs[i] );
        }
              

}
}
