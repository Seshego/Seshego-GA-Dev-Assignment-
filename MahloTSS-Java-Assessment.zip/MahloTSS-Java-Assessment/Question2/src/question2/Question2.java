/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import static java.lang.Double.parseDouble;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.text.DecimalFormat;
/**
 *
 * 
 */
public class Question2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here
        
        
          Scanner scanner = new Scanner(System.in);
          
        System.out.println("Make Choice");
        System.out.println("0 -  Exit");
        System.out.print("1 - Add student Details");
        System.out.println("\n2 - Display Student information");
        
      
        System.out.println(" Enter option below: ");
        int numb = Integer.parseInt(scanner.nextLine());
        
        if(numb == 0)
        {
            System.exit(0);
        }else
            if(numb == 1)
            {
                addDetails();
            }else
                if(numb == 2)
                {
                    display();
                }        
    
 }   
    
 //Adding student to the text file....
       
       public static  void addDetails()
       {
           Scanner scaner = new Scanner(System.in);
           
           System.out.print("Surname: " );
           String surname = scaner.nextLine();
           System.out.print("Name: " );
           String name = scaner.nextLine();
           System.out.print("course : " );
           String course = scaner.nextLine();
           
           System.out.print("Class test 1 :" );
           double ct1 = Double.parseDouble(scaner.nextLine());
           if(ct1<0 || ct1>100)
           {
           System.out.println("Test1 mark can only be between 0 - 100, please try again..");
            
           System.out.print("Class test 1 :" );
           ct1 = Double.parseDouble(scaner.nextLine());
           }
           
           System.out.print("Class test 2 :" );
           double ct2 = Double.parseDouble(scaner.nextLine());
             if(ct2<0)
           {
           System.out.println("Test2 mark can not be negative, please try again..");
            
           System.out.print("Class test 2 :" );
           ct2 = Double.parseDouble(scaner.nextLine());
           }
             
           System.out.print("Summative :" );
           double sm = Double.parseDouble(scaner.nextLine());
               if(sm<0 || sm>100)
           {
           System.out.println("Summative mark can not be negative, please try again..");
            
           System.out.print("Summative :" );
           sm = Double.parseDouble(scaner.nextLine());
           }
               
           System.out.print("Exam :" );
           double em = Double.parseDouble(scaner.nextLine());
           if(em<0 || em>100)
           {
           System.out.println("Exam mark can not be negative, please try again..");
            
           System.out.print("Exam :" );
           em = Double.parseDouble(scaner.nextLine());
           }
           
            File file = new File("Student.txt");
            
          try {
                if(!file.exists()){
                 System.out.println("New file created.");
                file.createNewFile();
                   }
            FileWriter fileWriter = new FileWriter(file, true);
               try (BufferedWriter out = new BufferedWriter(fileWriter)) {
                  String text = "\n" + surname + "," + name + "," + course + "," + ct1 + "," + ct2 + "," + sm + "," + em ;
                   out.write(text);
               }
           

                System.out.print(surname + " " + name + " details have been added to the text file" );
                
        Scanner scanner = new Scanner(System.in);
          
        System.out.println("Make Choice");
        System.out.println("0 -  Exit");
        System.out.print("1 - Add student Details");
        System.out.println("\n2 - Display Student information");
        
      
        System.out.println(" Enter option below: ");
        int numb = Integer.parseInt(scanner.nextLine());
        
        if(numb == 0)
        {
            System.exit(0);
        }else
            if(numb == 1)
            {
                addDetails();
            }else
                if(numb == 2)
                {
                    display();
                }
            
            
                    
        } catch (IOException ex) {
            System.out.print(ex);
        }
  
       }
       
       
       
       public static void calculateFinalMark()
       {
           
       }
       
       
       public static void display() throws FileNotFoundException, IOException
       {
//
        System.out.println("------------------Student Details----------------");
          
        File file = new File("C:\\Users\\dell\\Downloads\\Compressed\\Java Assessment\\Solution\\Question2\\Student.txt");
        String[] arr = null;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String str;
            while((str = br.readLine())!= null)
            {
                arr = str.split(",");
                
            }
        }
        
//Assigning Array values to appropriate variables     
            String surnam = arr[0];
            String fname = arr[1]; 
            String cours = arr[2]; 
            double results;
            double c11 = Double.parseDouble(arr[3]);
            double c22 = Double.parseDouble(arr[4]);
            double summative = Double.parseDouble(arr[5]);
            double exam = Double.parseDouble(arr[6]);
//Calculating final Mark            
            results =((c11+c22+summative)/3)*0.4 +(exam*0.6);
//Student output Results
            System.out.println("Surname :" + surnam);
            System.out.println("Name :" + fname );
            System.out.println("Course :" + cours );
              
//Geting student Grades  
          
    String grades="";   
          if(results <40)
          
          grades ="failed";
            else if(results >39 && results <50)
                grades ="D";      
            else if(results >49 && results<60)
                  grades ="C";
            else  if(results>59 && results<70)
                  grades="B";
            else if(results>69 &&results<80)
                  grades="A";
             else
                  grades ="A+";
          
     DecimalFormat df = new DecimalFormat("###.#"); 

     System.out.println( "Results :"+ df.format(results) +" "+grades);
     System.out.println("\n2");
   
 
       //Writing to Results.txt
             File filen = new File("Results.txt");
            
          try {
                if(!filen.exists()){
                 System.out.println("New file created.");
                filen.createNewFile();
                   }
            FileWriter fileWriter = new FileWriter(filen, true);
               try (BufferedWriter out = new BufferedWriter(fileWriter)) {
                  String text = "\n" + surnam + "," + fname + "," + cours +", FINAL RESULTS: "+df.format(results) ;
                   out.write(text);
               }
          
          } catch (IOException ex) 
          {
              System.out.print(ex);
        }
  //Menu             
     Scanner scanner = new Scanner(System.in);
          
        System.out.println("Make Choice");
        System.out.println("0 -  Exit");
        System.out.print("1 - Add student Details");
        System.out.println("\n2 - Display Student information");
        
   
        System.out.println("Enter option below: ");
        int numb = Integer.parseInt(scanner.nextLine());
        
        if(numb == 0)
        {
            System.exit(0);
        }else
            if(numb == 1)
            {
                addDetails();
            }else
                if(numb == 2)
                {
                    display();
                }

   }
}
        
       
   
    
  